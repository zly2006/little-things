﻿using MCCS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSCStest1
{
    class Program
    {
        static void Main(string[] args)
        {
            OpenTK.Toolkit.Init();
            Console.Title = "控制台 - log";
            Console.WriteLine("加载中");
            GameMain game = new GameMain();
            game.Run(60);
        }
    }
}
