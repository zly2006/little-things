﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Runtime.InteropServices;

namespace MCCS
{
    class ItemAbility
    {
        /// <summary>
        /// 伤害
        /// </summary>
        public int hurt;
        /// <summary>
        /// 防御
        /// </summary>
        public int defense;
        /// <summary>
        /// 饥饿值
        /// </summary>
        public int feed;

    }
    /// <summary>
    /// 附魔
    /// </summary>
    class Ench
    {
        public int id;
        public int level;
    }
    /// <summary>
    /// 实体
    /// </summary>
    class Entity
    {
        public uint[] uuid;
        public uint id = 0;
        public uint type = 0;
        /// <summary>
        /// 坐标
        /// </summary>
        public float x, y, z;
        /// <summary>
        /// 坐标速度
        /// </summary>
        public float dx, dy, dz;
        public string name = null;
        /// <summary>
        /// 装备
        /// </summary>
        Item[] wear;
        /// <summary>
        /// 手中
        /// </summary>
        Item item;
        public Entity(string json)
        {

        }
    }
    class Item
    {
        /// <summary>
        /// 默认名称-ID列表
        /// </summary>
        static List<string> IdNameList;
        public string name;
        public uint id = 0;
        public uint type = 0;
    }
    class Player
    {
        public string name;
        public uint[] uuid;
        /// <summary>
        /// 背包
        /// </summary>
        public Item[] Bag;
        /// <summary>
        /// 快捷栏（0-8）双持9 盔甲10-13
        /// </summary>
        public Item[] FastBar;
        public int ItemSelected;
        public delegate bool JoinGameArgs(Player player);
        /// <returns>返回false阻止此事件被系统捕获和操作</returns>
        event JoinGameArgs JoinGame;

    }
    class Block
    {
        /// <summary>
        /// 用何工具采集得到何物品
        /// </summary>
        Dictionary<int, int> ToolItem;
    }
    /// <summary>
    /// 程序主窗口类
    /// <br></br>
    /// 
    /// https://www.cnblogs.com/podolski/p/7406544.html
    /// 
    /// </summary>
    class GameMain : GameWindow
    {
        [DllImport("user32.dll")]
        private static extern int SetCursorPos(int x, int y);
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Title = "C#Minecraft";
            GL.ClearColor(0.25F,0.4F,0.7f,1f);
        }
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            Matrix4 modelview = Matrix4.LookAt(Vector3.Zero, Vector3.UnitZ, Vector3.UnitY);

            GL.MatrixMode(MatrixMode.Modelview);

            GL.LoadMatrix(ref modelview);
            GL.Begin();
            GL.Vertex3(-1.0f, -1.0f, 4.0f);
            GL.Color3(1.0f, 0.0f, 0.0f);
            GL.Vertex3(1.0f, -1.0f, 4.0f);
            GL.Vertex3(0.0f, 1.0f, 4.0f);
            GL.End();
            SwapBuffers();
        }
    }
}
